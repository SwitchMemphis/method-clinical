"use client";

import Image from "next/image";
import { useState } from "react";

export function ProductGallery({ productName, images }: { productName: string; images: readonly string[] }) {
  const [selected, setSelected] = useState(0);

  return (
    <figure className="flex min-w-0 flex-col justify-center rounded-card border border-border-subtle bg-surface-section-deep p-5 md:p-8">
      <Image
        src={images[selected]}
        alt={`AP Labs reference photo of ${productName}, view ${selected + 1}`}
        width={640}
        height={640}
        className="mx-auto aspect-square w-full max-w-sm object-contain"
        priority
      />
      {images.length > 1 && (
        <div role="group" aria-label="Reference photo views" className="mt-4 flex flex-wrap justify-center gap-2">
          {images.map((src, index) => (
            <button
              type="button"
              key={src}
              aria-label={`View photo ${index + 1}`}
              aria-pressed={index === selected}
              onClick={() => setSelected(index)}
              className="size-14 cursor-pointer overflow-hidden rounded-panel border border-border-subtle bg-surface-section aria-pressed:border-accent"
            >
              <Image src={src} alt="" width={56} height={56} className="size-full object-contain" />
            </button>
          ))}
        </div>
      )}
      <figcaption className="mt-4 text-center text-sm text-foreground-muted">AP Labs product photography · Reference preview</figcaption>
    </figure>
  );
}
