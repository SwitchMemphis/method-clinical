"use client";

import { useState } from "react";

export function ProductOptions({ strengths }: { strengths: readonly string[] }) {
  const [selected, setSelected] = useState(strengths[0]);
  return (
    <fieldset className="mt-7">
      <legend className="text-sm font-semibold">Select strength</legend>
      <div className="mt-3 flex flex-wrap gap-2">
        {strengths.map((strength) => (
          <label key={strength} className="flex min-h-11 cursor-pointer items-center gap-2 rounded-full border border-border-subtle px-4 py-2 text-sm has-checked:border-accent has-checked:bg-accent has-checked:text-action-primary-foreground">
            <input type="radio" name="catalog-strength" value={strength} checked={selected === strength} onChange={() => setSelected(strength)} className="accent-current" />
            {strength}
          </label>
        ))}
      </div>
    </fieldset>
  );
}
