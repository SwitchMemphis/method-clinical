import Image from "next/image";
import Link from "next/link";
import { ArrowLeft } from "lucide-react";

import { catalog } from "@/data/mocks/catalog";
import { generateMetadata } from "@/utils/seo/generate-page-metadata";
import { CatalogBrowser } from "./catalog-browser";

export const catalogMetadata = {
  ...generateMetadata({
    title: "Wholesale catalog | Method Clinical",
    description: "Browse the Method Clinical wholesale catalog preview.",
    url: "/catalog/",
  }),
  robots: { index: false, follow: false },
};

export function CatalogView() {
  return (
    <div className="bg-surface-section">
      <header className="flex w-full items-center justify-between gap-3 px-utility-gutter py-6">
        <Link href="/" aria-label="Method Clinical home">
          <Image src="/assets/flow-logo.png" width={548} height={175} alt="Method Clinical" className="h-auto w-utility-logo-compact sm:w-utility-logo" priority />
        </Link>
        <Link href="/" className="flex min-h-utility-target items-center gap-2 text-utility-body text-foreground-muted hover:text-accent">
          <ArrowLeft size={16} aria-hidden="true" /> Back to site
        </Link>
      </header>

      <main className="w-full px-utility-gutter pb-utility-section pt-6">
        <section className="relative isolate overflow-hidden rounded-card border border-border-subtle bg-surface-section-deep p-6 md:p-10">
          <div aria-hidden="true" className="pointer-events-none absolute inset-0 -z-10 bg-[url('/assets/helix-scene-poster.webp')] bg-cover bg-center opacity-20" />
          <p className="text-utility-label font-semibold tracking-widest text-accent uppercase">Provider portal · Catalog preview</p>
          <h1 className="mt-4 text-4xl leading-display font-extrabold tracking-tight md:text-6xl">Wholesale <span className="text-accent">catalog.</span></h1>
          <p className="mt-4 max-w-lg text-utility-body leading-relaxed text-foreground-muted">
            Browse the AP Labs reference assortment. Listings, specifications, and photos are for design review and do not represent Method Clinical inventory or lot results.
          </p>
        </section>

        <CatalogBrowser products={catalog} />
      </main>
    </div>
  );
}
