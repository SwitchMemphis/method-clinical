"use client";

import { Minus, Plus } from "lucide-react";
import { useState } from "react";

import { Button } from "@/components/ui/button";
import type { TestingContent } from "@/data/mocks/testing";
import { cn } from "@/lib/utils";

export interface TestingIndexProps {
  content: TestingContent;
}

const number = (index: number) => String(index + 1).padStart(2, "0");

/** Native disclosures stay usable before hydration and with JavaScript disabled. */
export function TestingIndex({ content }: TestingIndexProps) {
  const [selectedIndex, setSelectedIndex] = useState(0);
  const selected = content.layers[selectedIndex];

  return (
    <div className="mt-10 grid items-start gap-7 md:mt-12 md:grid-cols-[minmax(0,.86fr)_minmax(0,1.14fr)] md:gap-14 lg:mt-testing-index-gap lg:gap-10">
      <figure className="relative overflow-hidden rounded-card border border-border-subtle bg-surface-section-deep">
        <div aria-hidden="true" className="pointer-events-none absolute inset-0 bg-radial-[at_50%_45%] from-accent/10 via-transparent to-transparent" />
        <div className="relative flex items-center justify-between gap-3 p-4 text-[length:var(--testing-caption)] font-medium tracking-wider text-foreground-muted uppercase md:p-6 lg:p-testing-figure-inset lg:text-testing-label">
          <span>{content.diagramLabel}</span>
          <span className="shrink-0 text-accent">{content.diagramRange}</span>
        </div>
        <svg viewBox="0 0 360 380" aria-hidden="true" className="relative block h-36 w-full md:h-testing-diagram lg:h-testing-diagram-fit">
          {content.layers.map((layer, index) => ({ layer, index })).reverse().map(({ layer, index }) => {
            const y = 60 + index * 36;
            return (
              <g key={layer.title}>
                <path
                  d={`M55 ${y + 35} L180 ${y - 10} L305 ${y + 35} L180 ${y + 80} Z`}
                  className={cn(
                    "transition-colors duration-[var(--duration-fast)] ease-entrance motion-reduce:transition-none",
                    selectedIndex === index ? "fill-testing-selected stroke-accent" : "fill-testing-rest stroke-accent/25",
                  )}
                />
                <text x="316" y={y + 40} className="fill-foreground-muted text-[length:var(--testing-diagram-label)]">{number(index)}</text>
              </g>
            );
          })}
        </svg>
        <figcaption className="relative flex min-h-12 flex-wrap items-center justify-between gap-2 border-t border-border-subtle px-4 py-3 text-xs text-foreground-muted md:px-6 md:py-6 lg:min-h-testing-caption-fit lg:px-testing-figure-inset lg:py-testing-inset">
          <span className="text-[length:var(--testing-caption)] tracking-wide uppercase lg:text-testing-label">{content.selectionLabel}</span>
          <strong className="text-sm font-semibold text-accent md:text-xl lg:text-testing-row-title">{number(selectedIndex)} / {selected.shortLabel}</strong>
        </figcaption>
      </figure>

      <div aria-label={content.listLabel}>
        {content.layers.map((layer, index) => (
          <details
            key={layer.title}
            name="method-testing-layer"
            onToggle={(event) => {
              if (event.currentTarget.open) setSelectedIndex(index);
            }}
            className="group/layer border-b border-border-subtle first:border-t"
          >
            <summary className="grid min-h-14 cursor-pointer list-none grid-cols-[1.5rem_minmax(0,1fr)_1rem] items-center gap-2 py-5 outline-none focus-visible:rounded-panel focus-visible:ring-2 focus-visible:ring-accent focus-visible:ring-offset-4 focus-visible:ring-offset-surface-section md:grid-cols-[2rem_minmax(0,1fr)_1.1rem] md:gap-3 [&::-webkit-details-marker]:hidden lg:min-h-testing-row lg:py-testing-inset">
              <span className="text-xs font-medium text-foreground-muted group-open/layer:text-accent lg:text-testing-label">{number(index)}</span>
              <span className="text-base leading-snug font-medium tracking-tight group-open/layer:text-accent md:text-xl lg:text-testing-row-title">{layer.title}</span>
              <Plus aria-hidden="true" className="size-4 text-foreground-muted group-open/layer:hidden" strokeWidth={1.5} />
              <Minus aria-hidden="true" className="hidden size-4 text-accent group-open/layer:block" strokeWidth={1.5} />
            </summary>
            <div className="max-w-lg pb-7 pl-8 md:pr-4 md:pl-11 lg:max-w-none">
              {layer.detailHeading && <h3 className="mb-4 text-lg leading-snug font-semibold text-foreground">{layer.detailHeading}</h3>}
              <p className="text-base leading-relaxed text-foreground-muted lg:text-testing-body">{layer.description}</p>
              {layer.whyItMatters && layer.setsUsApart && (
                <dl className="mt-5 grid gap-7 border-t border-border-subtle/60 pt-5">
                  <div className="grid gap-3">
                    <dt className="text-xs leading-relaxed font-semibold tracking-widest text-accent uppercase">{content.whyLabel}</dt>
                    <dd className="text-base leading-relaxed text-foreground-muted lg:text-testing-body">{layer.whyItMatters}</dd>
                  </div>
                  <div className="grid gap-3">
                    <dt className="text-xs leading-relaxed font-semibold tracking-widest text-accent uppercase">{content.differenceLabel}</dt>
                    <dd className="text-base leading-relaxed text-foreground-muted lg:text-testing-body">{layer.setsUsApart}</dd>
                  </div>
                </dl>
              )}
              {layer.detailAction && (
                <Button href={layer.detailAction.href} className="mt-6 max-w-full px-5 text-sm font-semibold whitespace-normal">
                  {layer.detailAction.label}
                </Button>
              )}
            </div>
          </details>
        ))}
      </div>
    </div>
  );
}
