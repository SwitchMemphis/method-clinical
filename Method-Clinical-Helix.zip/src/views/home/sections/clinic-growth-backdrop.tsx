import { LazyDnaInk } from "@/components/scene/dna-ink";

export function ClinicGrowthBackdrop() {
  return (
    <div aria-hidden="true" className="pointer-events-none absolute inset-0 -z-10">
      <div className="absolute inset-0 bg-[url('/assets/helix-scene-poster.webp')] bg-cover bg-center opacity-45 lg:bg-contain lg:bg-no-repeat lg:opacity-65" />
      <div className="absolute inset-y-0 left-1/2 hidden w-[71.125rem] -translate-x-1/2 motion-safe:lg:block">
        <LazyDnaInk className="block size-full" controls={false} />
      </div>
      <div className="absolute inset-0 bg-linear-to-b from-surface-section/75 via-surface-section/20 to-surface-section/75" />
    </div>
  );
}
