import Image from "next/image";
import Link from "next/link";
import { ArrowLeft, ArrowDownRight } from "lucide-react";
import { REGISTRATION_CONTENT as content } from "@/data/mocks/registration";
import { generateMetadata } from "@/utils/seo/generate-page-metadata";
import { RegistrationForm } from "./registration-form";

export const registrationMetadata = generateMetadata({ title: "Register your clinic | Method Clinical", description: content.description, url: "/register/" });

export function RegisterView() {
  return <div className="bg-surface-section">
    <header className="mx-auto flex max-w-utility-content items-center justify-between gap-3 px-utility-gutter py-3">
      <Link href="/" aria-label="Method Clinical home" className="focus-visible:outline-2 focus-visible:outline-offset-4 focus-visible:outline-accent"><Image src="/assets/flow-logo.png" width={548} height={175} alt="Method Clinical" className="h-auto w-utility-logo-compact sm:w-40" priority /></Link>
      <Link href="/" className="flex min-h-utility-target items-center gap-2 text-utility-body text-foreground-muted hover:text-accent focus-visible:outline-2 focus-visible:outline-accent"><ArrowLeft size={16} aria-hidden="true" /><span>Back to site</span></Link>
    </header>
    <main className="mx-auto grid max-w-utility-content items-start gap-3 px-utility-gutter pb-utility-section pt-4 lg:grid-cols-3 lg:gap-10">
      <div className="flex flex-col items-start gap-3 lg:sticky lg:top-10">
        <p className="text-utility-label font-semibold tracking-widest text-accent uppercase">{content.eyebrow}</p>
        <h1 className="text-3xl leading-display sm:text-4xl font-extrabold tracking-tight">{content.title}<br /><span className="text-accent">{content.emphasis}</span></h1>
        <p className="max-w-lg text-utility-body leading-relaxed text-foreground-muted">{content.description}</p>
        <div className="flex items-center gap-3 border-t border-border-subtle pt-3 text-utility-small text-foreground-muted"><ArrowDownRight size={20} className="text-accent" aria-hidden="true" /><p>For clinics and licensed providers</p></div>
      </div>
      <div className="min-w-0 lg:col-span-2"><RegistrationForm /></div>
    </main>
  </div>;
}
