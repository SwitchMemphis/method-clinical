import type { ReactNode } from "react";
import type { RegistrationField } from "@/data/mocks/registration";
import { cn } from "@/lib/utils";

export const controlClass = "min-h-utility-control w-full min-w-0 rounded-panel border border-border-subtle bg-surface-section px-3 py-2 text-utility-body text-foreground placeholder:text-foreground-muted focus-visible:border-accent focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-accent";
export const labelClass = "flex flex-col gap-1.5 text-utility-body font-medium leading-relaxed text-foreground";

export function Field({ name, label, full, required, ...props }: RegistrationField) {
  return <label className={cn(labelClass, full && "sm:col-span-2")} htmlFor={name}>
    <span>{label}{required ? <span className="text-accent"> *</span> : <span className="font-normal text-foreground-muted"> (optional)</span>}</span>
    <input {...props} id={name} name={name} required={required} className={controlClass} />
  </label>;
}

export function FormSection({ number, title, children }: { number: number; title: string; children: ReactNode }) {
  return <fieldset id={`registration-${number}`} className="min-w-0 scroll-mt-8 border-b border-border-subtle pb-5 last:border-0">
    <legend className="mb-3 flex w-full items-center gap-3 text-utility-section-title font-semibold">
      <span aria-hidden="true" className="flex size-8 shrink-0 items-center justify-center rounded-full border border-border-subtle bg-surface-section text-utility-small font-medium text-accent">{String(number).padStart(2, "0")}</span>
      {title}
    </legend>
    <div className="grid min-w-0 gap-x-4 gap-y-3 sm:grid-cols-2">{children}</div>
  </fieldset>;
}

export function Choice({ name, label, value, onChange }: { name: string; label: string; value: string; onChange: (value: string) => void }) {
  return <fieldset className="sm:col-span-2">
    <legend className="mb-3 text-utility-body font-medium leading-relaxed">{label} <span className="text-accent">*</span></legend>
    <div className="grid grid-cols-2 gap-3">
      {["Yes", "No"].map(option => <label key={option} className="flex min-h-utility-control cursor-pointer items-center justify-center gap-3 rounded-panel border border-border-subtle bg-surface-section px-4 text-utility-body has-checked:border-accent has-checked:bg-testing-selected has-checked:text-accent has-focus-visible:outline-2 has-focus-visible:outline-offset-2 has-focus-visible:outline-accent">
        <input type="radio" name={name} value={option} required checked={value === option} onChange={() => onChange(option)} className="accent-accent" />{option}
      </label>)}
    </div>
  </fieldset>;
}
