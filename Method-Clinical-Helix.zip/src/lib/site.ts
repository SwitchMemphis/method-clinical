/**
 * Site-wide configuration — the single source of truth for SEO.
 *
 * Consumed by the metadata generator, `robots.ts`, `sitemap.ts`, and the
 * JSON-LD structured-data helper. Update the placeholder values per project.
 */
import { getServerEnv, publicEnv } from "@/env";

/**
 * Vercel's production domain, read at build time — the fallback when a deploy
 * doesn't set `NEXT_PUBLIC_SITE_URL` (none did: the live canonical said
 * localhost). Server-only: every consumer of `siteConfig` renders on the server.
 */
const vercelProduction = getServerEnv().VERCEL_PROJECT_PRODUCTION_URL;
import { BRAND } from "@/lib/brand";

export const siteConfig = {
  name: "Method Clinical",
  /** Used as the `<title>` when a page doesn't set its own. */
  title: "Method Clinical | Wholesale peptide supply",
  description:
    "Wholesale peptide supply for licensed providers. Explore our sourcing standards, testing process, and provider access.",
  /**
   * Public origin, no trailing slash. Drives canonical URLs, OG tags, the
   * sitemap, and JSON-LD. Set `NEXT_PUBLIC_SITE_URL` in production.
   */
  url:
    publicEnv.NEXT_PUBLIC_SITE_URL ??
    (vercelProduction ? `https://${vercelProduction}` : "http://localhost:3000"),
  /**
   * Open Graph / Twitter share image.
   *
   * Generated from the logo at request time by `src/app/opengraph-image.tsx`
   * rather than shipped as a static file — see that route. Next resolves the
   * `/opengraph-image` file convention automatically, so this path only exists
   * for callers that pass an explicit override.
   */
  ogImage: "/opengraph-image",
  author: "Method Clinical",
  /** Browser theme-color (address bar / PWA) — the brand green. */
  themeColor: "#07130f",
  /** Brand palette, shared with the generated icon and OG routes. */
  brand: BRAND,
} as const;
