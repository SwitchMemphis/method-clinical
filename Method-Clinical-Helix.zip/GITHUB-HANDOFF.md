# Method Clinical Helix

This is the editable Next.js source from the published Helix site, version 1, commit `a2bf37531512886405ce0c7ef86956e40b81f455`. The archive includes the mobile helix video and its still fallback in `public/assets/`. It excludes the private site's hosting binding.

## GitHub and local setup

1. Extract the ZIP and add the extracted contents to the root of your GitHub repository, including the dotfiles.
2. Use Node.js 22 LTS and Yarn Classic 1.22.22.
3. Run `yarn install --frozen-lockfile`, then `yarn dev`.
4. For a static production export, run `yarn build` and serve the `out/` directory at the root of your host. The build fetches Google Sans Flex. The current asset paths assume a root URL, so hosting under a repository subpath requires configuration.

The main routes are `/`, `/catalog/`, `/catalog/<product>/`, `/register/` and `/login/`. Account access and registration are frontend previews. See PROJECT-STATUS.md for the implementation history and integration limits.

The mobile hero uses the same video and poster as the published version. The longer standalone GIF discussed later in the chat is a separate asset.
