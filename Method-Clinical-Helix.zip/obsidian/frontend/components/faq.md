# Clinic FAQ

Eight owner-supplied questions at #faq, immediately before the final Provider Access section. `src/views/home/sections/faq.tsx` is server-rendered and takes `FaqContent` from `src/data/mocks/faq.ts`. Native details share name=method-clinic-faq for one-open behavior and start collapsed. Native summary supports pointer and keyboard with visible inset focus ring. Answers stay in document flow and remain available without hydration. Decorative icons are aria-hidden. Optional account action uses next/link to #contact with no prefetch.

Reuses current colors, typography, radius and spacing utilities. No new state, dependency, scene, asset, backend, FAQ structured-data claims or form. All provided topics retained; competitor identity/contact and unsupported instant-access wording adapted as documented in PROJECT-BRIEF.md. QA evidence and boundaries: PROJECT-STATUS.md.

Screen-fit correction: desktop uses local FAQ tokens for bounded typography, row spacing, 1120px content width and a 100svh minimum section. All eight questions plus any single expanded answer fit at 1280×720 in the tested content. Natural height can still grow for zoom or changed content. Mobile body remains 16px and row targets at least 48px. FAQ now sits immediately before the restored final Provider Access. See PROJECT-STATUS.md for measurements.

Header spacing: local 16–24px flex gap, normal heading letter spacing and 0.08em additional word spacing. All eight questions still fit with the account answer open at the checked 1280×720 viewport.
